# Currency Format Input Field

A Pen created on CodePen.io. Original URL: [https://codepen.io/ducwp/pen/jOXQxJd](https://codepen.io/ducwp/pen/jOXQxJd).

Auto format currency input field with commas and decimals if needed. This is how I would personally expect one to work. Works left to right without forcing user to enter 00 cents if there is none. Text is automatically formatted with commas and cursor is placed back where user left off after formatting vs cursor moving to the end of the input. Validation is on KeyUp and a final validation is done on blur.